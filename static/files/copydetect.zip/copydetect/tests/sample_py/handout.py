# used for same_name_only test
import numpy as np
