__version__ = "0.4.3"

from .detector import CopyDetector, CodeFingerprint, compare_files
